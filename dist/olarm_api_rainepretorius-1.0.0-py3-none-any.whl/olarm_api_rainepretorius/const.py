"""Module that stores all the constants for the integration."""
import logging
VERSION = "1.0.0"

GITHUB_TOKEN = "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"

LOGGER = logging.getLogger(__package__)

CONF_SCAN_INTERVAL = 5

class ServiceCall:
    def __init__(self):
        pass